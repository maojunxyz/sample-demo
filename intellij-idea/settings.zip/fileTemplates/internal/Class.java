#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 * Description: $DESCRIPTION
 * Created by ${USER}
 * Date: ${YEAR}/${MONTH}/${DAY}
 * Time: ${TIME}
 */
public class ${NAME} {
}
